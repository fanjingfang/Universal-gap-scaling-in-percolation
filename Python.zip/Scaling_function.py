#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Wed May  2 10:27:44 2018

@author: jingfang
"""

import numpy as np
import matplotlib.pyplot as pl
from scipy import stats
from scipy.optimize import curve_fit

def func(x, a, b, c):
    return a + b*pow(x,-c)
def Scaling(path,dimension,LL):
    r=1
    L=[]
    gap=[]
    rc=[]
    S=[]
    
    
    
    gap_a=[]
    rc_a=[]
    S_a=[]
    gap_s=[]
    rc_s=[]
    S_s=[]
    
    
    for x in LL:
        try:
            data= np.loadtxt(path+dimension+'distribution_'+str(x)+'_p'+str(r)+'.out')
#            data= np.loadtxt(path+dimension+'distribution_'+str(x)+'.out')
            dgap=data[:,0]
            drc=data[:,1]
            dS=data[:,4]
            L.append(x)
            gap.append(dgap)
            rc.append(drc)
            S.append(dS)
            gap_a.append(np.average(dgap))
            gap_s.append(np.std(dgap))
            rc_a.append(np.average(drc))
            rc_s.append(np.std(drc))
            S_a.append(np.average(dS))
            S_s.append(np.std(dS))
            print x               
        except:
            continue
    outfile = open(path+dimension+'_site_'+str(r),'wb')
    for x in range(len(L)):
        outfile.write('%d %.10f %.10f %.10f %.10f %.10f %.10f\n' %(L[x],gap_a[x],gap_s[x],rc_a[x],rc_s[x],S_a[x],S_s[x]))
    outfile.close()
    slope1, intercept1, r_value1, p_value1, std_err1 = stats.linregress(np.log(L), np.log(gap_a))
    slope2, intercept2, r_value2, p_value2, std_err2 = stats.linregress(np.log(L), np.log(gap_s))
    popt, pcov = curve_fit(func, L, rc_a)
    slope4, intercept4, r_value4, p_value4, std_err4 = stats.linregress(np.log(L), np.log(rc_s))
    slope5, intercept5, r_value5, p_value5, std_err5 = stats.linregress(np.log(L), np.log(S_a))
    slope6, intercept6, r_value6, p_value6, std_err6 = stats.linregress(np.log(L), np.log(S_s))
    
    outfile = open(path+dimension+'_critical_exponts','wb')
    outfile.write('%.10f %.10f %.10f %.10f %.10f %.10f %.10f %.10f %.10f %.10f %.10f %.10f\n' %(slope1,std_err1,slope2,std_err2,popt[0],-popt[2],slope4,std_err4,
                                                                             slope5,std_err5,slope6,std_err6))
    outfile.close()
    
    
    
    
    
    
    for x in range(len(L)):
        LL=L[x]
        nbins = 20 ##10,15,50       
        outfile = open(path+'Non_Scale'+str(nbins)+'_'+str(r)+'L_'+str(LL),'wb')
        outfile1 = open(path+'CDFNon_Scale'+str(nbins)+'_'+str(r)+'L_'+str(LL),'wb')
        
    
        data1=gap[x]-gap_a[x]
        data2=rc[x]-rc_a[x]
        data3=S[x]-S_a[x]
        LENGTHDATA =len(data1)*1.0

        n, bins = np.histogram(data1, nbins,density=1)
        cumulative = np.cumsum(n)
        pdfx1 = np.zeros(n.size)
        pdfy1 = np.zeros(n.size)
        cdfy1 = np.zeros(n.size)
        
        for k in range(n.size):
            pdfx1[k] = 0.5*(bins[k]+bins[k+1])
            pdfy1[k] = n[k]
            cdfy1[k] = cumulative[k]/LENGTHDATA
        n, bins = np.histogram(data2, nbins,density=1)
        cumulative = np.cumsum(n)

        pdfx2 = np.zeros(n.size)
        pdfy2 = np.zeros(n.size)
        cdfy2 = np.zeros(n.size)

        for k in range(n.size):
            pdfx2[k] = 0.5*(bins[k]+bins[k+1])
            pdfy2[k] = n[k]
            cdfy2[k] = cumulative[k]/LENGTHDATA
    
        n, bins = np.histogram(data3, nbins,density=1)
        cumulative = np.cumsum(n)
        pdfx3 = np.zeros(n.size)
        pdfy3 = np.zeros(n.size)
        cdfy3 = np.zeros(n.size)

        for k in range(n.size):
            pdfx3[k] = 0.5*(bins[k]+bins[k+1])
            pdfy3[k] = n[k]
            cdfy3[k] = cumulative[k]/LENGTHDATA
    
        for y in range(nbins):
            outfile.write('%.10f %.10f %.10f %.10f %.10f %.10f\n'%(pdfx1[y],pdfy1[y],pdfx2[y],pdfy2[y],pdfx3[y],pdfy3[y]))
            outfile1.write('%.10f %.10f %.10f %.10f %.10f %.10f\n'%(pdfx1[y],cdfy1[y],pdfx2[y],cdfy2[y],pdfx3[y],cdfy3[y]))

        outfile.close()
        outfile1.close()
   
        outfile = open(path+'Scale'+str(nbins)+'_'+str(r)+'L_'+str(LL),'wb')
        outfile1 = open(path+'CDFScale'+str(nbins)+'_'+str(r)+'L_'+str(LL),'wb')
    
        data1=data1*pow(LL,-slope2)
        data2=data2*pow(LL,-slope4)
        data3=data3*pow(LL,-slope6)
        n, bins = np.histogram(data1, nbins,density=1)
        cumulative = np.cumsum(n)
        pdfx1 = np.zeros(n.size)
        pdfy1 = np.zeros(n.size)
        cdfy1 = np.zeros(n.size)
        
        for k in range(n.size):
            pdfx1[k] = 0.5*(bins[k]+bins[k+1])
            pdfy1[k] = n[k]
            cdfy1[k] = cumulative[k]/LENGTHDATA
        n, bins = np.histogram(data2, nbins,density=1)
        cumulative = np.cumsum(n)

        pdfx2 = np.zeros(n.size)
        pdfy2 = np.zeros(n.size)
        cdfy2 = np.zeros(n.size)

        for k in range(n.size):
            pdfx2[k] = 0.5*(bins[k]+bins[k+1])
            pdfy2[k] = n[k]
            cdfy2[k] = cumulative[k]/LENGTHDATA
    
        n, bins = np.histogram(data3, nbins,density=1)
        cumulative = np.cumsum(n)
        pdfx3 = np.zeros(n.size)
        pdfy3 = np.zeros(n.size)
        cdfy3 = np.zeros(n.size)

        for k in range(n.size):
            pdfx3[k] = 0.5*(bins[k]+bins[k+1])
            pdfy3[k] = n[k]
            cdfy3[k] = cumulative[k]/LENGTHDATA
    
        for y in range(nbins):
            outfile.write('%.10f %.10f %.10f %.10f %.10f %.10f\n'%(pdfx1[y],pdfy1[y],pdfx2[y],pdfy2[y],pdfx3[y],pdfy3[y]))
            outfile1.write('%.10f %.10f %.10f %.10f %.10f %.10f\n'%(pdfx1[y],cdfy1[y],pdfx2[y],cdfy2[y],pdfx3[y],cdfy3[y]))

        outfile.close()
        outfile1.close()
#        outfile = open(path+'Betla_'+str(r)+'L_'+str(LL),'wb')
##        data_s1 = np.loadtxt(path+dimension+'SG_L'+str(LL)+'_p'+str(r)+'.dat')
#        data_s1 = np.loadtxt(path+dimension+'SG_L'+str(LL)+'.dat')
#
#        for p_x in range(len(data_s1)):
#            if(data_s1[:,0][p_x]-popt[0]>0):
#                outfile.write('%.10f %.10f\n' %(data_s1[:,0][p_x]-popt[0],data_s1[:,1][p_x]))
#        outfile.close()

        

        

def Scaling_SF(path,dimension,LL,r):
    #r=1
    L=[]
    gap=[]
    rc=[]
    S=[]
    
    
    
    gap_a=[]
    rc_a=[]
    S_a=[]
    gap_s=[]
    rc_s=[]
    S_s=[]
    
    
    for x in LL:

        try:
            data= np.loadtxt(path+dimension+'distribution_'+str(x)+'_lambda_'+str(r)+'.out')
            #data= np.loadtxt(path+dimension+'distribution_'+str(x)+'.out')
            dgap=data[:,0]
            drc=data[:,1]
            dS=data[:,2]
            L.append(x)
            gap.append(dgap)
            rc.append(drc)
            S.append(dS)
            gap_a.append(np.average(dgap))
            gap_s.append(np.std(dgap))
            rc_a.append(np.average(drc))
            rc_s.append(np.std(drc))
            S_a.append(np.average(dS))
            S_s.append(np.std(dS))
            print x               
        except:
            continue
    outfile = open(path+dimension+'_site_'+str(r),'wb')
    for x in range(len(L)):
        outfile.write('%d %.10f %.10f %.10f %.10f %.10f %.10f\n' %(L[x],gap_a[x],gap_s[x],rc_a[x],rc_s[x],S_a[x],S_s[x]))
    outfile.close()
    slope1, intercept1, r_value1, p_value1, std_err1 = stats.linregress(np.log(L), np.log(gap_a))
    slope2, intercept2, r_value2, p_value2, std_err2 = stats.linregress(np.log(L), np.log(gap_s))
    popt, pcov = curve_fit(func, L, rc_a)
    slope4, intercept4, r_value4, p_value4, std_err4 = stats.linregress(np.log(L), np.log(rc_s))
    slope5, intercept5, r_value5, p_value5, std_err5 = stats.linregress(np.log(L), np.log(S_a))
    slope6, intercept6, r_value6, p_value6, std_err6 = stats.linregress(np.log(L), np.log(S_s))
    
    outfile = open(path+dimension+'_critical_exponts','wb')
    outfile.write('%.10f %.10f %.10f %.10f %.10f %.10f %.10f %.10f %.10f %.10f %.10f %.10f\n' %(slope1,std_err1,slope2,std_err2,popt[0],-popt[2],slope4,std_err4,
                                                                             slope5,std_err5,slope6,std_err6))
    outfile.close()
    
    
    
    
    
    
    for x in range(len(L)):
        LL=L[x]
    
        outfile = open(path+'Non_Scale_'+str(r)+'L_'+str(LL),'wb')
    
        data1=gap[x]-gap_a[x]
        data2=rc[x]-rc_a[x]
        data3=S[x]-S_a[x]  
        nbins = 20   
        n, bins = np.histogram(data1, nbins, density=1)
        pdfx1 = np.zeros(n.size)
        pdfy1 = np.zeros(n.size)
        for k in range(n.size):
            pdfx1[k] = 0.5*(bins[k]+bins[k+1])
            pdfy1[k] = n[k]
        n, bins = np.histogram(data2, nbins, density=1)
        pdfx2 = np.zeros(n.size)
        pdfy2 = np.zeros(n.size)
        for k in range(n.size):
            pdfx2[k] = 0.5*(bins[k]+bins[k+1])
            pdfy2[k] = n[k]
    
        n, bins = np.histogram(data3, nbins, density=1)
        pdfx3 = np.zeros(n.size)
        pdfy3 = np.zeros(n.size)
        for k in range(n.size):
            pdfx3[k] = 0.5*(bins[k]+bins[k+1])
            pdfy3[k] = n[k]
    
        for y in range(nbins):
            outfile.write('%.10f %.10f %.10f %.10f %.10f %.10f\n'%(pdfx1[y],pdfy1[y],pdfx2[y],pdfy2[y],pdfx3[y],pdfy3[y]))
        outfile.close()
    
        outfile = open(path+'Scale_'+str(r)+'L_'+str(LL),'wb')
    
        data1=data1*pow(LL,-slope2)
        data2=data2*pow(LL,-slope4)
        data3=data3*pow(LL,-slope6)
        n, bins = np.histogram(data1, nbins, density=1)
        pdfx1 = np.zeros(n.size)
        pdfy1 = np.zeros(n.size)
        for k in range(n.size):
            pdfx1[k] = 0.5*(bins[k]+bins[k+1])
            pdfy1[k] = n[k]
        n, bins = np.histogram(data2, nbins, density=1)
        pdfx2 = np.zeros(n.size)
        pdfy2 = np.zeros(n.size)
        for k in range(n.size):
            pdfx2[k] = 0.5*(bins[k]+bins[k+1])
            pdfy2[k] = n[k]
    
        n, bins = np.histogram(data3, nbins, density=1)
        pdfx3 = np.zeros(n.size)
        pdfy3 = np.zeros(n.size)
        for k in range(n.size):
            pdfx3[k] = 0.5*(bins[k]+bins[k+1])
            pdfy3[k] = n[k]
    
        for y in range(nbins):
            outfile.write('%.10f %.10f %.10f %.10f %.10f %.10f\n'%(pdfx1[y],pdfy1[y],pdfx2[y],pdfy2[y],pdfx3[y],pdfy3[y]))
        outfile.close()
        
        outfile = open(path+'Betla_'+str(r)+'L_'+str(LL),'wb')
#        data_s1 = np.loadtxt(path+dimension+'SG_L'+str(LL)+'_p'+str(r)+'.dat')
        data_s1 = np.loadtxt(path+dimension+'N'+str(LL)+'_lambda_'+str(r)+'.dat')

        for p_x in range(len(data_s1)):
            if(data_s1[:,0][p_x]-popt[0]>0):
                outfile.write('%.10f %.10f\n' %(data_s1[:,0][p_x]-popt[0],data_s1[:,1][p_x]))
        outfile.close()
       
        
def Scaling_REAL_WORLD(path,inputx,LL):
        data= np.loadtxt(path+inputx+'.out')
        dgap=data[:,0]
        drc=data[:,1]
        dS=data[:,4]
        data1=dgap-np.average(dgap)
        data2=drc-np.average(drc)
        data3=dS-np.average(dS)  
        nbins = 20   
        n, bins = np.histogram(data1, nbins, density=1)
        pdfx1 = np.zeros(n.size)
        pdfy1 = np.zeros(n.size)
        for k in range(n.size):
                pdfx1[k] = 0.5*(bins[k]+bins[k+1])
                pdfy1[k] = n[k]
        n, bins = np.histogram(data2, nbins, density=1)
        pdfx2 = np.zeros(n.size)
        pdfy2 = np.zeros(n.size)
        for k in range(n.size):
                pdfx2[k] = 0.5*(bins[k]+bins[k+1])
                pdfy2[k] = n[k]
        
        n, bins = np.histogram(data3, nbins, density=1)
        pdfx3 = np.zeros(n.size)
        pdfy3 = np.zeros(n.size)
        for k in range(n.size):
                pdfx3[k] = 0.5*(bins[k]+bins[k+1])
                pdfy3[k] = n[k]
    
        outfile = open(path+inputx+'Non_Scale','wb')
        
        for y in range(nbins):
                outfile.write('%.10f %.10f %.10f %.10f %.10f %.10f\n'%(pdfx1[y],pdfy1[y],pdfx2[y],pdfy2[y],pdfx3[y],pdfy3[y]))
        outfile.close()    
    
        outfile = open(path+inputx+'Scale_2D','wb')
        slope2 = - 0.052
        slope4 = -0.375
        slope6 = 0.96
        
    
        data1=data1*pow(LL,-slope2)
        data2=data2*pow(LL,-slope4)
        data3=data3*pow(LL,-slope6)
        n, bins = np.histogram(data1, nbins,density=1)
        cumulative = np.cumsum(n)
        pdfx1 = np.zeros(n.size)
        pdfy1 = np.zeros(n.size)
        cdfy1 = np.zeros(n.size)
        
        for k in range(n.size):
            pdfx1[k] = 0.5*(bins[k]+bins[k+1])
            pdfy1[k] = n[k]
        n, bins = np.histogram(data2, nbins,density=1)
        cumulative = np.cumsum(n)

        pdfx2 = np.zeros(n.size)
        pdfy2 = np.zeros(n.size)
        cdfy2 = np.zeros(n.size)

        for k in range(n.size):
            pdfx2[k] = 0.5*(bins[k]+bins[k+1])
            pdfy2[k] = n[k]
    
        n, bins = np.histogram(data3, nbins,density=1)
        cumulative = np.cumsum(n)
        pdfx3 = np.zeros(n.size)
        pdfy3 = np.zeros(n.size)
        cdfy3 = np.zeros(n.size)

        for k in range(n.size):
            pdfx3[k] = 0.5*(bins[k]+bins[k+1])
            pdfy3[k] = n[k]
    
        for y in range(nbins):
            outfile.write('%.10f %.10f %.10f %.10f %.10f %.10f\n'%(pdfx1[y],pdfy1[y],pdfx2[y],pdfy2[y],pdfx3[y],pdfy3[y]))

        outfile.close()

    
        outfile = open(path+inputx+'Scale_3D','wb')
        slope2 = - 0.157
        slope4 = -0.379
        slope6 = 0.84
        
    
        data1=data1*pow(LL,-slope2)
        data2=data2*pow(LL,-slope4)
        data3=data3*pow(LL,-slope6)
        n, bins = np.histogram(data1, nbins,density=1)
        cumulative = np.cumsum(n)
        pdfx1 = np.zeros(n.size)
        pdfy1 = np.zeros(n.size)
        cdfy1 = np.zeros(n.size)
        
        for k in range(n.size):
            pdfx1[k] = 0.5*(bins[k]+bins[k+1])
            pdfy1[k] = n[k]
        n, bins = np.histogram(data2, nbins,density=1)
        cumulative = np.cumsum(n)

        pdfx2 = np.zeros(n.size)
        pdfy2 = np.zeros(n.size)
        cdfy2 = np.zeros(n.size)

        for k in range(n.size):
            pdfx2[k] = 0.5*(bins[k]+bins[k+1])
            pdfy2[k] = n[k]
    
        n, bins = np.histogram(data3, nbins,density=1)
        cumulative = np.cumsum(n)
        pdfx3 = np.zeros(n.size)
        pdfy3 = np.zeros(n.size)
        cdfy3 = np.zeros(n.size)

        for k in range(n.size):
            pdfx3[k] = 0.5*(bins[k]+bins[k+1])
            pdfy3[k] = n[k]
    
        for y in range(nbins):
            outfile.write('%.10f %.10f %.10f %.10f %.10f %.10f\n'%(pdfx1[y],pdfy1[y],pdfx2[y],pdfy2[y],pdfx3[y],pdfy3[y]))

        outfile.close()    
        
 
        outfile = open(path+inputx+'Scale_ER','wb')
        slope2 = - 1.0/3
        slope4 = - 1.0/3
        slope6 = 2.0/3
        
    
        data1=data1*pow(LL,-slope2)
        data2=data2*pow(LL,-slope4)
        data3=data3*pow(LL,-slope6)
        n, bins = np.histogram(data1, nbins,density=1)
        cumulative = np.cumsum(n)
        pdfx1 = np.zeros(n.size)
        pdfy1 = np.zeros(n.size)
        cdfy1 = np.zeros(n.size)
        
        for k in range(n.size):
            pdfx1[k] = 0.5*(bins[k]+bins[k+1])
            pdfy1[k] = n[k]
        n, bins = np.histogram(data2, nbins,density=1)
        cumulative = np.cumsum(n)

        pdfx2 = np.zeros(n.size)
        pdfy2 = np.zeros(n.size)
        cdfy2 = np.zeros(n.size)

        for k in range(n.size):
            pdfx2[k] = 0.5*(bins[k]+bins[k+1])
            pdfy2[k] = n[k]
    
        n, bins = np.histogram(data3, nbins,density=1)
        cumulative = np.cumsum(n)
        pdfx3 = np.zeros(n.size)
        pdfy3 = np.zeros(n.size)
        cdfy3 = np.zeros(n.size)

        for k in range(n.size):
            pdfx3[k] = 0.5*(bins[k]+bins[k+1])
            pdfy3[k] = n[k]
    
        for y in range(nbins):
            outfile.write('%.10f %.10f %.10f %.10f %.10f %.10f\n'%(pdfx1[y],pdfy1[y],pdfx2[y],pdfy2[y],pdfx3[y],pdfy3[y]))

        outfile.close()         
        