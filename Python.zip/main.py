#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Wed May  2 11:16:24 2018

@author: jingfang
"""
execfile("/home/jingfang/code/python/Universality/Scaling_function.py")


LL=[32,64,128,256,512,1024,2048,4096]
dimension='2d'
path='/home/jingfang/CLUSTER_DATA/CODE/C/Universal/2D/data/'
Scaling(path,dimension,LL)

LL=[8,16,32,64,128,256]
dimension='3d'
path='/extdata/code/percolation/3D/data/'
Scaling(path,dimension,LL)

LL =[10000,20000,40000,80000,160000,320000,640000]
dimension='TYPEVI'
path='/home/jingfang/CLUSTER_DATA/TYPEVI/'
Scaling(path,dimension,LL)

LL =[80000,160000,320000,640000,1280000,2560000,5120000,10240000]
dimension='ER'
path = '/home/jingfang/code/c/ER/data/'
Scaling(path,dimension,LL)

LL =[80000,160000,320000,640000,1280000,2560000,5120000,10240000]
dimension='EP'
path = '/home/jingfang/code/c/Explosive/data/'
Scaling(path,dimension,LL)


####################SF###########################
#LL =[320000,640000,1280000,2560000,5120000,10240000]
#dimension='SF_'
#path='/home/jingfang/CLUSTER_DATA/SF/'
#for r in [2.5,3.5,4.5]:
#    Scaling_SF(path,dimension,LL,r)




NETWORK_LIST=['Humanproteinproteininteractions','WikipediaTalknetwork'
              ,'DBLPcollaborationnetwork']

LL=[3134,2394385,425957]
path='/home/jingfang/CLUSTER_DATA/CODE/C/Universal/REAL_WORLD/'
n=0
for inputx in NETWORK_LIST:
    Leng = LL[n]
    Scaling_REAL_WORLD(path,inputx,Leng)
    n+=1