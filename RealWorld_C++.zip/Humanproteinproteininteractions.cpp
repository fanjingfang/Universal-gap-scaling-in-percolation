#include <stdlib.h>
#include <stdio.h>
#include "mt19937ar.h"
#include <time.h>
#include <iostream>
#include <string>
#include <vector>
#include <sstream>
#include <fstream>
#include <mpi.h>
#include <queue>
#include <algorithm>    // std::random_shuffle
#include <ctime>        // std::time
#include <cstdlib>      // std::rand, std::srand
#include <unistd.h>
#include <errno.h>
using namespace std;

#define AVE 10000

//Humanproteinproteininteractions, 3134, 6726
string str1in = "Humanproteinproteininteractions"; 

int const NN = 3134;
//int const L2 = L*L;
int const tstep = 6726;
double p=1;
mt19937 rand_num;
int ptr[NN];			//Array of pointers


double Gm[tstep];
vector <int> SAMPLE;

int LINKS[tstep][2];

double Largest_gap =0;
double t1=0;
double Second_Largest_gap =0;
double t2=0;
double Largest_cluster1 =0;
double Largest_cluster2 =0;

int findroot(int i)
{
    if(ptr[i]<0)return i;
    return ptr[i]=findroot(ptr[i]);
}
string int2str(int i)
{
    string s;
    stringstream ss(s);
    ss << i;

    return ss.str();
}
string double2str(double i)
{
    string s;
    stringstream ss(s);
    ss << i;

    return ss.str();
}

void readdata()
{
    SAMPLE.clear();
    string finalname,finalname2,finalname3;
    ifstream fintemp1,fintemp2,fintemp3;
    stringstream ss;

    finalname="/home/jingfang/data/"+str1in+"/LINKS.txt";
    fintemp1.open(finalname.c_str());
    if(!fintemp1)
    {

        cout<<finalname<<" does not exit!"<<endl;
        exit(1);
    }

    int r1,r2;

    for(int i=0;i<tstep;i++)
    {
        fintemp1 >> r1;
        fintemp1 >> r2;
        SAMPLE.push_back(i);
        LINKS[i][0] = r1;
        LINKS[i][1] = r2;  
        
           
    }
} 

void percolate( FILE *fp)
{

    double s1 =0;
    double t_1=0;
    double t_2=0;
    double s2 =0;

    int Largest1=0;
    int Largest2=0;

    int temps=0;
    int big=1;
    int r1,r2;
    for(int i=0;i<NN;i++) ptr[i]=-1;
    std::random_shuffle (SAMPLE.begin(), SAMPLE.end());
    for(int i=0;i<tstep;i++)
    {
        int node1=LINKS[SAMPLE[i]][0] ;//[0,1) the same as [0,N-1].
        int node2=LINKS[SAMPLE[i]][1] ;//[0,1) the same as [0,N-1].
        r1= findroot(node1);

        r2= findroot(node2);

        if(r1!=r2)
        {
            if(ptr[r1]>ptr[r2])
            {
                ptr[r2]+=ptr[r1];
                ptr[r1]=r2;
                r1=r2;
            }
            else
            {
                ptr[r1]+=ptr[r2];
                ptr[r2]=r1;

            }

        }

        if(-ptr[r1] >big) big = -ptr[r1];


        double temp_1 = double ( big -temps)/NN;
        temps = big;
         if(temp_1 >=s1)
         {
             s2 = s1;
             t_2 = t_1;
             s1 = temp_1;
             t_1 = double (i)/tstep;
             Largest1 = big;
         }
         else if(temp_1 >=s2)
         {
             s2 = temp_1;
             t_2 = double (i)/tstep;
             Largest2 = big;
         }
         Gm[i] += double (big)/NN;


    }
    cout<<SAMPLE.size()<<endl;

    // Largest_gap +=s1;
    // t1 +=t_1;
    // Second_Largest_gap +=s2;
    // t2 +=t_2;
    // Largest_cluster1 +=Largest1;
    // Largest_cluster2 +=Largest2;



     setbuf(fp,NULL);
     fprintf(fp,"%.10f %.10f %.10f %.10f  %d %d\n", s1,t_1,s2,t_2,Largest1,Largest2);




    //*****************************
    //out_put_sample(bridge_bond);
    //cout<<bridge_bond.size()<<endl;
    //bridge_bond.clear();


    //**************************



} 


int main(int argc,char **argv)
{
        double g_s[tstep];

    int rank;
    int size;

    string str4=".dat";
    string str5=".out";
    char cwd[1024];
    if (getcwd(cwd, sizeof(cwd)) != NULL)
        fprintf(stdout, "Current working dir: %s\n", cwd);
    else
        perror("getcwd() error");

     string dir = "/p/tmp/jingfang/CODE/C/Universal/REAL_WORLD/";
    string filename1=dir+str1in+str4;
    string filename2=dir+str1in+str5;
    //string filename=dir+"ERspanning.dat";
    FILE *fp;
    FILE *fp1;
    //FILE *fp2;
    //fp2=fopen(filename.c_str(),"ab");
    fp=fopen(filename1.c_str(),"wb");
    fp1=fopen(filename2.c_str(),"ab");
    readdata();

    //rand_num.init_genrand((unsigned)time( NULL ));
    //rand_num.init_genrand(8);
    //std::srand ((unsigned)time( NULL ));
    //std::srand (1);
    MPI_Init(&argc,&argv);
    MPI_Comm_size(MPI_COMM_WORLD, &size);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    rand_num.init_genrand((unsigned)time( NULL )+rank);
    std::srand ((unsigned)time( NULL )+rank);

    for(int i=rank+1;i<=AVE;i+=size)
    {
        //cout<<i<<endl;
        percolate(fp1);
    }
    MPI_Reduce(&Gm,&g_s,tstep,MPI_DOUBLE,MPI_SUM,0,MPI_COMM_WORLD);

     if(rank==0)
    {
    for(int i = 0;i<tstep-1;++i)
    {
        fprintf(fp," %.10f %.10f\n",  double(i+1)/NN,g_s[i+1]/AVE);

    }
    }
    fclose(fp);
    fclose(fp1);
    MPI_Finalize();

    return 0;
}








