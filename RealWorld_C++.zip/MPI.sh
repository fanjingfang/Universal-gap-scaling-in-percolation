#!/bin/bash

## SBATCH --qos=priority
##  SBATCH --qos=short
## SBATCH --qos=medium
#SBATCH --qos=standby
#SBATCH --job-name=jingfang_job
#SBATCH --account=epicc
#SBATCH --time=23:00:00
#SBATCH --output=jing-%j.out
#SBATCH --error=jing-%j.err
# #SBATCH --workdir=/home/yanglui/test/test5/RNN/classification/2
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=16
##SBATCH --mem=64000
# #SBATCH --partition=ram_gpu
# #SBATCH --gres=gpu:1



echo "------------------------------------------------------------"
echo "SLURM JOB ID: $SLURM_JOBID"
echo "$SLURM_NTASKS tasks"
echo "$SLURM_NTASKS_PER_NODE tasks per node"
echo "Running on nodes: $SLURM_NODELIST"
echo "------------------------------------------------------------"

module purge
module load intel/2018.3

# To run on a login node, uncomment this line
#     export I_MPI_FABRICS=shm:shm
# To run on a compute node, either do
#     unset I_MPI_FABRICS 
# or
#     export I_MPI_FABRICS=shm:dapl

## srun version (requires SLURM's process management interface (libpmi) to srun)
#export I_MPI_PMI_LIBRARY=/p/system/slurm/lib/libpmi.so
#srun -n $SLURM_NTASKS $PWD/percolation

## mpirun version
## First, comment out the I_MPI_PMI_LIBRARY line above.
#echo SLURM JOB NODELIST   : $SLURM_JOB_NODELIST
#echo SLURM TASKS PER NODE : $SLURM_TASKS_PER_NODE
I_MPI_DEBUG=5 mpirun -bootstrap slurm -n $SLURM_NTASKS $PWD/percolation
