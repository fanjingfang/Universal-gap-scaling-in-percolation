#include <stdlib.h>
#include <stdio.h>
#include "mt19937ar.h"
#include <time.h>
#include <iostream>
#include <string>
#include <vector>
#include <sstream>
#include <fstream>

#include <queue>
using namespace std;


#define L   4096
#define NN (L*L)
#define AVE 10000
double p=1;
int const tstep = 2*NN;
mt19937 rand_num;
int ptr[NN];			//Array of pointers
int point1[2*NN];		//point 1 to be connected
int point2[2*NN];		//point 1 to be connected


double Gm[tstep];

double Largest_gap =0;
double t1=0;
double Second_Largest_gap =0;
double t2=0;

double Largest_cluster1 =0;
double Largest_cluster2 =0;

int findroot(int i)
{
    if(ptr[i]<0)return i;
    return ptr[i]=findroot(ptr[i]);
}
string int2str(int i)
{
    string s;
    stringstream ss(s);
    ss << i;

    return ss.str();
}
string double2str(double i)
{
    string s;
    stringstream ss(s);
    ss << i;

    return ss.str();
}



// void out_put_sample(vector<int> bridge_bond)
// {
//     string str1=int2str((int)L);
//     string str2="_Sample.dat";
//     string filename1=str1+str2;
//     FILE *fp;
//     fp=fopen(filename1.c_str(),"wb");
//     int temp[NN];
//     int max=0;
//     int min=NN;
//     for (int i=0;i<NN;i++)
//     {
//         int r1 = findroot(i);
//         temp[i] =r1;
//         if(r1>max) max =r1;
//         if(r1<min) min =r1;
//     }
//     for(int i=0;i<bridge_bond.size();i++)
//     {
//         int node1 =point1[bridge_bond.at(i)];
//         int node2 =point2[bridge_bond.at(i)];
//         temp[node1] =(max+min)/2;
//         temp[node2] =(max+min)/2;

//     }

//     for (int i=0;i<NN;i++)
//     {
//         // int r1 = findroot(i);
//         fprintf(fp,"%d\n",temp[i]);
//     }
//     fclose(fp);



// }

void percolate(  FILE *fp)
{

    deque <int> mydeque;
    double s1 =0;
    double t_1=0;
    double t_2=0;
    double s2 =0;

    int Largest1=0;
    int Largest2=0;


    int temps=0;
    for(int i=0;i<tstep;i++)
    {
        if(i<NN)		//connect the right side point
        {
            if((i+1)%L != 0)
            {
                point1[i]=i;
                point2[i]=i+1;
                mydeque.push_back(i);
            }

            //**************************
            else
            {
                point1[i]=i;
                point2[i]=i+1-L;
                mydeque.push_back(i);
            }
            //**************************

        }
        else			//connect the below side point
        {
            int A = i-NN;
            if(A+L<NN)
            {
                point1[i]=A;
                point2[i]=A+L;
                mydeque.push_back(i);

            }
            //**************************
            else
            {
                point1[i]=A;
                point2[i]=A+L-NN;
                mydeque.push_back(i);
            }
            //**************************

        }

    }

    int big=1;
    int r1,r2;
    for(int i=0;i<NN;i++) ptr[i]=-1;
    for(int i=1;i<tstep;i++)
    {
        int n1=mydeque.size()*rand_num.genrand_real2();
        int q1 = mydeque.at(n1);
        swap( mydeque.at(0),mydeque.at(n1));
        mydeque.pop_front();
        int node1 = point1[q1];
        int node2 = point2[q1];
        r1= findroot(node1);
        r2= findroot(node2);
        if(r1!=r2)
        {
            if(ptr[r1]>ptr[r2])
            {
                ptr[r2]+=ptr[r1];
                ptr[r1]=r2;
                r1=r2;
            }
            else
            {
                ptr[r1]+=ptr[r2];
                ptr[r2]=r1;

            }

        }
        if(-ptr[r1] >big) big = -ptr[r1];


        double temp_1 = double ( big -temps)/NN;
        temps = big;
        if(temp_1 >=s1)
        {
            s2 = s1;
            t_2 = t_1;
            s1 = temp_1;
            t_1 = double (i)/tstep;
            Largest1 = big;
        }
        else if(temp_1 >=s2)
        {
            s2 = temp_1;
            t_2 = double (i)/tstep;
            Largest2 = big;
        }
        Gm[i] += double (big)/NN;
    }

    Largest_gap +=s1;
    t1 +=t_1;
    Second_Largest_gap +=s2;
    t2 +=t_2;
    Largest_cluster1 +=Largest1;
    Largest_cluster2 +=Largest2;



    setbuf(fp,NULL);
    fprintf(fp,"%.10f %.10f %.10f %.10f  %d %d\n", s1,t_1,s2,t_2,Largest1,Largest2);




    //*****************************
    //out_put_sample(bridge_bond);
    //cout<<bridge_bond.size()<<endl;
    //bridge_bond.clear();


    //**************************



}


int main(int argc,char **argv)
{

    string str1=int2str((int)L);
    string str2="2dSG_L";
    string str3="2ddistribution_";
    string str4=".dat";
    string str5=".out";
    //string str6=int2str((int)m);
    string str7="_p";
    string str8=double2str(p);
    string dir = "/home/jingfang/code/percolation/2D/data/";




    //string filename1=str2+str1+str7+str6+str4;
    //string filename2=str3+str1+str7+str6+str5;
    //string filename3=str1+str4;
    string filename1=dir+str2+str1+str7+str8+str4;
    string filename2=dir+str3+str1+str7+str8+str5;
    string filename=dir+"2dspanning.dat";




    FILE *fp;
    FILE *fp1;
    FILE *fp2;

    fp2=fopen(filename.c_str(),"ab");


    fp=fopen(filename1.c_str(),"wb");
    fp1=fopen(filename2.c_str(),"ab");
    //fp2=fopen(filename3.c_str(),"ab");
    //cout<<L<<endl;


    rand_num.init_genrand((unsigned)time( NULL ));
    //rand_num.init_genrand(1);
    for(int i=0;i<AVE;i++)
    {
        //cout<<i<<endl;
        percolate(fp1);
    }





    for(int i = 1;i<tstep;++i)
    {
        fprintf(fp," %.10f %.10f\n",  double(i)/tstep,Gm[i]/AVE);

    }
    fprintf(fp2,"%d %.10f %.10f %.10f %.10f %.10f  %.10f\n", L,Largest_gap/AVE,t1/AVE,Second_Largest_gap/AVE,t2/AVE,Largest_cluster1/AVE,Largest_cluster2/AVE);




    fclose(fp);
    fclose(fp1);
    fclose(fp2);



    return 0;
}









